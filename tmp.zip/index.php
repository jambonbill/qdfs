<?php
/**
 * Qdfs, start page
 */


$title = 'qdfs';//your title here
$basepath = realpath("./");
$clipath = "./cli/";

include "$clipath/main.php";
